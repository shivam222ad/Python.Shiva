import pytz
from datetime import datetime


# Function to greet the user based on the time in Nepal
def greet_user():
    # Set the timezone to Nepal
    nepal_timezone = pytz.timezone("Asia/Kathmandu")

    # Get the current time in Nepal timezone
    nepal_time = datetime.now(nepal_timezone)

    # Extract the current hour in Nepal
    current_hour = nepal_time.hour
    print(f"Current time in Nepal: {nepal_time.strftime('%Y-%m-%d %H:%M:%S')}"
          )  # Print the current time in Nepal

    # Greet the user based on the hour in Nepal
    if current_hour < 12:
        print("Good Morning!")
    elif 12 <= current_hour < 18:
        print("Good Afternoon!")
    else:
        print("Good Evening!")


# Call the function to greet the user
greet_user()
